
package mayıntarlası;

import java.util.Random;
import java.util.Scanner;

public class MayınTarlası {
 public static int [][] TabloyuDoldur (int satir, int sutun){
     
     Random rnd=new Random();
     int [][] matris=new int[satir][sutun];
     int i=0;
     while(i<satir){
         int j=0;
         while(j<sutun){
             matris[i][j]=rnd.nextInt(2);
             j=j+1;
         }
         i=i+1;
     }
      return matris;
 }
  
    public static void main(String[] args) {
       Scanner klavye=new Scanner (System.in);
        System.out.println("Satır büyüklüğünü giriniz");
        int a=klavye.nextInt();
        System.out.println("Sütun büyüklüğünü giriniz");
        int b=klavye.nextInt();
        int [][] matris2= TabloyuDoldur(a,b);
        int puan=0;
        boolean durum=true;
        while(durum){
            System.out.println("Seçtiğiniz konumun satır değerini giriniz");
            int c=klavye.nextInt();
            System.out.println("Seçtiğiniz konumun sütun değerini giriniz");
            int d=klavye.nextInt();
            if(matris2[c][d]==1){
                durum=false;
            }else{
               puan=puan+10;
                System.out.println("HARİKA! DEVAM..");
            }
                    
                    
        }
        System.out.println("OYUN BİTTİ! PUANINIZ:"+puan);
    }
    
}
